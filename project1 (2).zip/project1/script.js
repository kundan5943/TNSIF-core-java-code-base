let currentPlayer = 1;
let scores = [0, 0];
let winningScore = 50;
let numPlayers = 2;

const dice = document.getElementById("dice");
const rollBtn = document.getElementById("rollBtn");
const resetBtn = document.getElementById("resetBtn");
const message = document.getElementById("message");
const rollSound = document.getElementById("rollSound");
const targetScoreInput = document.getElementById("targetScore");
const playerCountSelect = document.getElementById("playerCount");
const playersContainer = document.getElementById("playersContainer");
const diceContainer = document.getElementById("diceContainer");

function createPlayers(n) {
  playersContainer.innerHTML = "";
  diceContainer.innerHTML = "";
  scores = Array(n).fill(0);
  for (let i = 1; i <= n; i++) {
    // Player display
    const playerDiv = document.createElement("div");
    playerDiv.id = `player${i}`;
    playerDiv.className = "player" + (i === 1 ? " active" : "");
    playerDiv.innerHTML = `Player ${i}: <span id="score${i}">0</span>`;
    playersContainer.appendChild(playerDiv);

    // Dice display for each player
    const diceImg = document.createElement("img");
    diceImg.id = `dice${i}`;
    diceImg.src = "images/dice1.svg";
    diceImg.alt = `Dice for Player ${i}`;
    diceImg.className = "player-dice" + (i === 1 ? " active-dice" : "");
    diceContainer.appendChild(diceImg);
  }
}

window.onload = () => {
  numPlayers = parseInt(playerCountSelect.value);
  createPlayers(numPlayers);

  const saved = localStorage.getItem("diceGameSave");
  if (saved) {
    const data = JSON.parse(saved);
    currentPlayer = data.currentPlayer;
    scores = data.scores;
    winningScore = data.winningScore;
    numPlayers = data.numPlayers || numPlayers;
    targetScoreInput.value = winningScore;
    playerCountSelect.value = numPlayers;
    createPlayers(numPlayers);
    updateScores();
    updateActivePlayer();
  }
};

playerCountSelect.addEventListener("change", () => {
  numPlayers = parseInt(playerCountSelect.value);
  currentPlayer = 1;
  createPlayers(numPlayers);
  rollBtn.disabled = false;
  message.textContent = "";
  updateScores();
  updateActivePlayer();
  localStorage.removeItem("diceGameSave");
});

rollBtn.addEventListener("click", () => {
  winningScore = parseInt(targetScoreInput.value);
  let total = Math.floor(Math.random() * 6) + 1;
  scores[currentPlayer - 1] += total;

  // Animate and update only the current player's dice
  for (let i = 1; i <= numPlayers; i++) {
    const diceImg = document.getElementById(`dice${i}`);
    if (diceImg) {
      diceImg.classList.remove("animate");
      diceImg.classList.remove("active-dice");
      if (i === currentPlayer) {
        diceImg.src = `images/dice${total}.svg`;
        diceImg.classList.add("animate");
        diceImg.classList.add("active-dice");
        setTimeout(() => diceImg.classList.remove("animate"), 500);
      }
    }
  }

  rollSound.play();
  updateScores();

  if (scores[currentPlayer - 1] >= winningScore) {
    message.textContent = `🎉 Player ${currentPlayer} Wins!`;
    rollBtn.disabled = true;
    saveGame(true);
    return;
  }

  currentPlayer = currentPlayer === numPlayers ? 1 : currentPlayer + 1;
  updateActivePlayer();
  saveGame();
});

resetBtn.addEventListener("click", () => {
  scores = Array(numPlayers).fill(0);
  currentPlayer = 1;
  rollBtn.disabled = false;
  message.textContent = "";
  updateScores();
  updateActivePlayer();
  localStorage.removeItem("diceGameSave");
});

function updateScores() {
  for (let i = 1; i <= numPlayers; i++) {
    const scoreSpan = document.getElementById(`score${i}`);
    if (scoreSpan) scoreSpan.textContent = scores[i - 1];
  }
}

function updateActivePlayer() {
  for (let i = 1; i <= numPlayers; i++) {
    const playerDiv = document.getElementById(`player${i}`);
    if (playerDiv) playerDiv.classList.toggle("active", currentPlayer === i);
  }
}

function saveGame(finished = false) {
  const data = {
    scores,
    currentPlayer,
    winningScore,
    numPlayers,
    finished
  };
  localStorage.setItem("diceGameSave", JSON.stringify(data));
}